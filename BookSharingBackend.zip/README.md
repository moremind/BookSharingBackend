## python微信小程序后端
> flask flask-restplus

## 小程序前端请参看
[frontend](https://github.com/hirCodd/BookSharing)
