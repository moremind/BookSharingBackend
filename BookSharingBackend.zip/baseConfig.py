# 小程序用户微信登陆密钥
app_id = 'wxb27ac135346a05ef'
secret = '28b70d35360b5bdacd2a5f9992b8f6fd'
grant_type = 'authorization_code'

# 腾讯云COS上传文件密钥
QCOS_APPID = '1251602255'
QCOS_SECRET_ID = 'AKID60f4E9JGUTCAuP8nbAXeWAYgYA2ihUWI'
QCOS_SECRET_KEY = 'g7JK6dw3xc3FDwQfeNp1zhxyiPt75uTm'
QCOS_BUCKET_NAME = 'test-1251602255'


baseConfig = {
    'app_id': app_id,
    'secret': secret,
    'grant_type': grant_type,
    QCOS_APPID: QCOS_APPID,
    QCOS_SECRET_ID: QCOS_SECRET_ID,
    QCOS_SECRET_KEY: QCOS_SECRET_KEY
}