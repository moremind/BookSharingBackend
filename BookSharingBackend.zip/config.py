
import os
basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    """
    :基础配置类
    """
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'u0L1lR$U$JgsZF$3'
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True

    @staticmethod
    def init_app(app):
        pass

class DevelopmentConfig(Config):
    """
    :开发环境配置类
    """
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:admin@123456@127.0.0.1/book_sharing"
    METADATA_DATABASE_URI = "mysql+pymysql://root:admin@123456@127.0.0.1/db_book_sharing"

class TestingConfig(Config):
    """
    :测试环境配置类
    """
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:admin@123456@127.0.0.1/book_sharing"

class ProductionConfig(Config):
    """
    :生产环境配置类
    """
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:admin@123456@127.0.0.1/book_sharing"

# 微信小程序app_id/secret
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig,
}
